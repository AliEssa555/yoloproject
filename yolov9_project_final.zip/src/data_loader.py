
def get_dataloaders(config):
    # Ultralytics YOLO models use .fit internally, no need for custom DataLoader setup
    return None, None
