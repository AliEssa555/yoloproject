
def load_model(config):
    print("Simulating model loading with config:", config)
    return "YOLOv9_Model"  # Replace with actual model
